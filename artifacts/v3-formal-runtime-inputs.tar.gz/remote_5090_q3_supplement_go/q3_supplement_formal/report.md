# SCI-Q3 independent supplement

- Status: `Q3_SUPPLEMENT_GO`
- P2 overall: `0.047275`
- Wang-Xie adapted overall: `0.131137`
- Dai adapted overall: `0.433670`
- P2 vs Wang-Xie improvement CI: `[0.5958, 0.6788]`
- P2 vs Dai improvement CI: `[0.8810, 0.9001]`
